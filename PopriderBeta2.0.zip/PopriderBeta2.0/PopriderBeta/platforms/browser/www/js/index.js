var fuelsum;
var foodsum;
var roomsum;
var actsum;
var extsum;
var currency;
var personname;
var daysstay;
var totalmembers;
var x;
var y;


// Function of home section

function home(){
    personname = document.getElementById("personname").value;
    daysstay = document.getElementById("daysstay").value;
    totalmembers = document.getElementById("totalmembers").value;
    x = document.getElementById("currency").selectedIndex;
    y = document.getElementById("currency").options;
    if (personname==""|| daysstay==""|| totalmembers ==""){
alert("You must enter the values");
    }
    else{
    document.getElementById("fuelcurrency").innerHTML = y[x].text;
    document.getElementById("homesection").style.display = "none";
    document.getElementById("fuelsection").style.display = "block";}
}

// Function of fuel section

function fuel(){
    var kms = document.getElementById("kms").value;
    var mileage = document.getElementById("mileage").value;
    var fuelprice = document.getElementById("fuelprice").value;
    if (kms==""|| mileage==""||  fuelprice==""){
        alert("You must enter the values");
    }
    else{
    fuelsum = kms / mileage *(fuelprice)*2;
    document.getElementById("foodcurrency").innerHTML = y[x].text;
    document.getElementById("foodcurrency2").innerHTML = y[x].text;
    document.getElementById("fuelsection").style.display = "none";
    document.getElementById("foodsection").style.display = "block";
}
}

// Function of food section

function food(){
    var breakfastcost = document.getElementById("breakfastcost").value;
    var extrafoodcost = document.getElementById("extrafoodcost").value;
    if (breakfastcost==""|| extrafoodcost==""){
        alert("You must enter the values");
    }
    else{
    foodsum = (breakfastcost * daysstay * totalmembers) + +(extrafoodcost* daysstay * totalmembers);
    document.getElementById("roomcurrency").innerHTML = y[x].text;
    document.getElementById("roomsection").style.display="block";
    document.getElementById("foodsection").style.display="none";}
}


// Function of room section

function room(){
    var roomprice = document.getElementById("roomprice").value;
    var membersperroom = document.getElementById("membersperroom").value;
    if(roomprice=="" || membersperroom=="" ){
        alert("You must enter the values");
    }
    else{
    roomsum = totalmembers / membersperroom * (roomprice*daysstay);
    document.getElementById("activitiessection").style.display="block";
    document.getElementById("roomsection").style.display="none";}
}


// Function of activities section
function activities(){
    var act1 = document.getElementById("act1").value;
    var act2 = document.getElementById("act2").value;
    var act3 = document.getElementById("act3").value;
    var act4 = document.getElementById("act4").value;
    actsum = +act1 + +act2 + +act3 + +act4;
    document.getElementById("extrassection").style.display="block"
    document.getElementById("activitiessection").style.display="none"
}



// Function of extras section

function extras(){
    var ext1 = document.getElementById("ext1").value;
    var ext2 = document.getElementById("ext2").value;
    var ext3 = document.getElementById("ext3").value;
    var ext4 = document.getElementById("ext4").value;
    var extsum = +ext1 + +ext2 + +ext3 + +ext4;
    document.getElementById("resultsection").style.display="block"
    document.getElementById("extrassection").style.display="none"
    document.getElementById("fueltotal").innerHTML = parseInt(fuelsum)+" "+ y[x].text;
    document.getElementById("foodtotal").innerHTML = parseInt(foodsum)+ " "+ y[x].text;
    document.getElementById("roomtotal").innerHTML = parseInt(roomsum)+ " "+ y[x].text;
    document.getElementById("activitiestotal").innerHTML = parseInt(actsum)+ " "+ y[x].text;
    document.getElementById("extrastotal").innerHTML = (extsum)+ " "+ y[x].text;
    sumall = parseInt(fuelsum+foodsum+roomsum+actsum+extsum);
    document.getElementById("resultdisplay1").innerHTML = sumall+ " "+ y[x].text;
    document.getElementById("eachsum").innerHTML = parseInt(sumall / totalmembers) + " " +y[x].text ;
}


